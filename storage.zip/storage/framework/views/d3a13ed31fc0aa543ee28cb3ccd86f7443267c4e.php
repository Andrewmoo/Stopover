<?php $__env->startSection('content'); ?>
  <div class="row">
  <div class="col-6">
          <div class="jumbotron SCO J-margin text-center">
            <h1><span class="SOColour">S</span>topover</h1>

            <?php echo Form::open([
              'action' => 'RoomsController@search',
              'method' => 'GET'
            ]); ?>

              
              <div class="row form-group cPost">
                <div class="col-sm-1">
                  <?php echo e(Form::label('from', 'From:')); ?>

                </div>
                <div class="col-sm-6">
                  <?php echo e(Form::date('from', '', ['class' => 'form-control'])); ?>

                </div>
              </div>
              <div class="row form-group cPost">
                  <div class="col-sm-1">
                    <?php echo e(Form::label('to', 'To:')); ?>

                  </div>
                  <div class="col-sm-6">
                    <?php echo e(Form::date('to', '', ['class' => 'form-control'])); ?>

                  </div>
              </div>
              
              <?php echo e(Form::submit('Search', ['class'=>'btn btn-primary'])); ?>

            <?php echo Form::close(); ?>


      </div>
    </div>
  </div>



<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.indexLayout', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>