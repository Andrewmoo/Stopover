<?php $__env->startSection('content'); ?>
<div class="container J-margin">
  <h1>Book </h1>
  <?php echo Form::open(['action' => 'BookingsController@store', 'method' => 'POST']); ?>

    <div class="form-group cPost">
      <?php echo e(Form::label('from', 'Date of check-in:')); ?>

      <?php echo e(Form::date('from', '', ['class' => 'form-control'])); ?>

    </div>
    <div class="form-group cPost">
      <?php echo e(Form::label('to', 'Date of check-out:')); ?>

      <?php echo e(Form::date('to', '', ['class' => 'form-control'])); ?>

    </div>
    <?php echo e(Form::hidden('guest_id', $guest_id)); ?>

    <?php echo e(Form::hidden('room_id', $room_id)); ?>

    <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

  <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>