<?php $__env->startSection('content'); ?>
    <div class="card">
        <h1 class="card-header"><?php echo e($hotel->name); ?></h1>
        <div class="card-body">
            <div class="row">
                <div class="col-2 border-right">
                    Address:
                </div>
                <div class="col-6">
                    <?php echo e($hotel->address); ?>

                </div>
            </div>
            <div class="row">
                <div class="col-2 border-right border-top">
                    Country:
                </div>
                <div class="col-6 border-top">
                    <?php echo e($hotel->country); ?>

                </div>
            </div>
            <div class="row">
                <div class="col-2 border-right border-top">
                    Phone number:
                </div>
                <div class="col-6 border-top">
                    <?php echo e($hotel->phone); ?>

                </div>
            </div>
            <div class="row">
                <div class="col-2 border-right border-top">
                    Contact email:
                </div>
                <div class="col-6 border-top">
                    <?php echo e($hotel->email); ?>

                </div>
            </div>
            <div class="row">
                <div class="col-2 border-right border-top">
                    Rooms available:
                </div>
                <div class="col-6 border-top">
                    <?php echo e(count($rooms)); ?>

                </div>
            </div>

            <?php if(!Auth::guest() && auth()->user()->type != 'guest'): ?>
                <div class="row col-12">
                <?php echo Form::open(['action' => ['HotelsController@destroy', $hotel->id], 'method' => 'POST']); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <a class="btn btn-primary" href="<?php echo e($hotel->id); ?>/edit">Edit</a>
                    <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                <?php echo Form::close(); ?>

                </div>
            <?php endif; ?>
        </div>
    </div>

    <!-- Room listings -->
    <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <?php if($room->booked == 0): ?>
        <div class="card mt-3 mb-3">
            <h5 class="card-header"><a href="/rooms/<?php echo e($room->id); ?>">Listing <?php echo e($room->id); ?></a></h5>
            <div class="card-body">
                <!-- Single beds -->
                <?php if($room->singleBeds > 0): ?>
                    <p>
                        <?php echo e($room->singleBeds); ?> single bed(s)
                    </p>
                <?php endif; ?>

                <!-- Double beds -->
                <?php if($room->doubleBeds > 0): ?>
                    <p>
                        <?php echo e($room->doubleBeds); ?> double bed(s)
                    </p>
                <?php endif; ?>

                <!-- Bathroom/en-suite -->
                <p>
                    <?php if($room->bathroom == 0): ?>
                        No bathroom in room.
                    <?php else: ?>
                        En-suite.
                    <?php endif; ?>
                </p>

                <!-- Wi-Fi -->
                <p>
                    <?php if($room->wifi == 0): ?>
                        No free Wi-Fi.
                    <?php else: ?>
                        Free Wi-Fi.
                    <?php endif; ?>
                </p>

                <!-- Wi-Fi -->
                <p>
                    <?php if($room->parking == 0): ?>
                        No free parking.
                    <?php else: ?>
                        Free parking.
                    <?php endif; ?>
                </p>

                <!-- Wi-Fi -->
                <p>
                    <?php if($room->breakfast == 0): ?>
                        Breakfast not included.
                    <?php else: ?>
                        Breakfast included.
                    <?php endif; ?>
                </p>
            </div>
        </div>
        <?php endif; ?>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>