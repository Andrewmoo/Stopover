<?php $__env->startSection('content'); ?>
<div class="container J-margin">
  <h1>Add hotel information</h1>
  <?php echo Form::open(['action' => 'HotelsController@store', 'method' => 'POST']); ?>

    <div class="form-group cPost">
      <?php echo e(Form::label('name', 'Name:')); ?>

      <?php echo e(Form::text('name', old('name'), ['class' => 'form-control', 'placeholder' => 'Name of hotel'])); ?>

    </div>
    <div class="form-group cPost">
      <?php echo e(Form::label('address', 'Address:')); ?>

      <?php echo e(Form::text('address', old('address'), ['class' => 'form-control', 'placeholder' => 'Street name, city, province'])); ?>

    </div>
    <div class="form-group cPost">
        <?php echo e(Form::label('country', 'Country:')); ?>

        <?php echo e(Form::text('country', old('country'), ['class' => 'form-control', 'placeholder' => 'Country'])); ?>

    </div>
    <div class="form-group cPost">
        <?php echo e(Form::label('phone', 'Phone number:')); ?>

        <?php echo e(Form::text('phone', old('phone'), ['class' => 'form-control', 'placeholder' => 'e.g. +353 867868954'])); ?>

    </div>
    <div class="form-group cPost">
        <?php echo e(Form::label('email', 'Email address:')); ?>

        <?php echo e(Form::text('email', old('email'), ['class' => 'form-control', 'placeholder' => 'example@example.com'])); ?>

    </div>
    <?php echo e(Form::hidden('user_id', $user_id)); ?>

    <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

  <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>