<?php $__env->startSection('content'); ?>
<div class="row">
    <div class="col-12">
        <div class="card card-dark secondaryColor">
            <div class="card-body">
            <?php if(count($rooms)  == 0): ?>
                <p>There are no results</p>
            <?php else: ?>
                <?php echo Form::open([
                  'action' => 'RoomsController@search',
                  'method' => 'GET'
                ]); ?>

                  <div class="form-row align-items-center mb-3">
                    <div class="col-auto text-white">
                      <?php echo e(Form::label('from', 'Showing results for time period from:', ['class' => 'form-label'])); ?>

                    </div>
                    <div class="col-auto">
                      <div class="input-group mb-2">
                        <div class="input-group-prepend">
                          <div class="input-group-text"><i class="fas fa-calendar"></i></div>
                        </div>
                        <?php echo e(Form::date('from', (isset($from) ? $from : ''), ['class' => 'form-control form-control-sm'])); ?>

                      </div>
                    </div>
                    <div class="col-auto text-white">
                      <?php echo e(Form::label('to', ' to ', ['class' => 'form-label'])); ?>

                    </div>
                    <div class="col-auto">
                      <div class="input-group mb-2">
                        <div class="input-group-prepend">
                          <div class="input-group-text"><i class="fas fa-calendar"></i></div>
                        </div>
                        <?php echo e(Form::date('to', (isset($to) ? $to : ''), ['class' => 'form-control form-control-sm'])); ?>

                      </div>
                    </div>
                    <div class="col-auto">
                      <?php echo e(Form::submit('Search', ['class'=>'btn btn-primary btn-sm mb-2'])); ?>

                    </div>
                  </div>
                <?php echo Form::close(); ?>

                <?php $__currentLoopData = $rooms; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $room): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <div class="mb-3 card card-light flex-row flex-wrap secondaryColor h-100" style="background-color: rgba(255, 255, 255, 0.3) !important">
                    <div class="card-header border-0">
                      <img src="/storage/images/room_images/<?php echo e($room->room_image); ?>">
                    </div>
                    <div class="card-body text-white px-3">
                        <!-- Single beds -->
                        <?php if($room->singleBeds > 0): ?>
                              <p>
                                  <i class="fas fa-bed align-middle" style="font-size: 1.5rem; font-color: #">
                                  </i>
                                  <span class="align-middle">
                                      <?php if($room->singleBeds > 1): ?>
                                          &nbsp;<?php echo e($room->singleBeds); ?> single beds
                                      <?php else: ?>
                                          &nbsp;<?php echo e($room->singleBeds); ?> single bed
                                      <?php endif; ?>
                                  </span>
                              </p>
                          <?php endif; ?>

                          <!-- Double beds -->
                          <?php if($room->doubleBeds > 0): ?>
                          <p>
                                  <i class="fas fa-bed align-middle" style="font-size: 1.5rem; font-color: #">
                                  </i>
                                  <span class="align-middle">
                                      <?php if($room->doubleBeds > 1): ?>
                                          &nbsp;<?php echo e($room->doubleBeds); ?> double beds
                                      <?php else: ?>
                                          &nbsp;<?php echo e($room->doubleBeds); ?> double bed
                                      <?php endif; ?>
                                  </span>
                              </p>
                          <?php endif; ?>

                          <!-- Bathroom/en-suite -->
                          <p>
                              <?php if($room->bathroom == 1): ?>
                                  <p>
                                      <i class="fas fa-shower align-middle text-info" style="font-size: 1.5rem"></i>
                                      <span class="align-middle">En-suite.</span>
                                  </p>
                              <?php endif; ?>
                          </p>

                          <!-- Wi-Fi -->
                          <p>
                              <?php if($room->wifi == 1): ?>
                                  <p>
                                      <i class="fas fa-wifi align-middle text-primary" style="font-size: 1.5rem; font-color: #"></i>
                                      <span class="align-middle">Wi-Fi.</span>
                                  </p>
                              <?php endif; ?>
                          </p>

                          <!-- Parking -->
                          <p>
                              <?php if($room->parking == 1): ?>
                                  <p>
                                      <i class="fas fa-car align-middle text-warning" style="font-size: 1.5rem; font-color: #"></i>
                                      <span class="align-middle">Free parking.</span>
                                  </p>
                              <?php endif; ?>
                          </p>

                          <!-- Breakfast -->
                          <p>
                              <?php if($room->breakfast == 1): ?>
                                  <p>
                                      <i class="fas fa-utensils align-middle" style="font-size: 1.5rem; font-color: #"></i>
                                      <span class="align-middle">Breakfast.</span>
                                  </p>
                              <?php endif; ?>
                          </p>
                    </div>
                    <div class="card-header text-white px-3 py-3 d-flex h-100">
                        <a class="btn btn-success btn-lg align-self-center" href="/rooms/<?php echo e($room->id); ?>">Select Room</a>
                    </div>
                  </div>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

            <?php endif; ?>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>