<?php $__env->startSection('content'); ?>
  <h1>Edit Room</h1>
  <?php echo Form::open(['action' => ['RoomsController@update', $room->room_id], 'method' => 'POST']); ?>

    <div class = "form-group cPost">
      <?php echo e(Form::label('description', 'Description')); ?>

      <?php echo e(Form::textarea('description', $room->description, ['class' => 'form-control', 'placeholder' => 'Description'])); ?>

    </div>
    <div class = "form-group cPost">
      <?php echo e(Form::label('facilities', 'Facilities')); ?>

      <?php echo e(Form::textarea('facilities', $room->facilities, ['class' => 'form-control', 'placeholder' => 'Facilities'])); ?>

    </div>
    <div class = "form-group cPost">
      <?php echo e(Form::label('noBeds', 'Number Of Beds')); ?>

      <?php echo e(Form::selectRange('noBeds', 1, 6)); ?>

    </div>
    <?php echo e(Form::hidden('_method', 'PUT')); ?>

    <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

  <?php echo Form::close(); ?>

<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>