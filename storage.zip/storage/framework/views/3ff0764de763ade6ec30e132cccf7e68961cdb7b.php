<?php $__env->startSection('content'); ?>
<div class="container J-margin">
  <h1>Create listing</h1>
  <?php echo Form::open(['action' => 'RoomsController@store', 'method' => 'POST', 'enctype' => 'multipart/form-data']); ?>

    <div class="form-group cPost">
      <?php echo e(Form::label('singleBeds', 'Number of single beds:')); ?>

      <?php echo e(Form::selectRange('singleBeds', 0, 6)); ?>

    </div>
    <div class="form-group cPost">
      <?php echo e(Form::label('doubleBeds', 'Number of double beds:')); ?>

      <?php echo e(Form::selectRange('doubleBeds', 0, 6)); ?>

    </div>
    <div class="form-group cPost">
      <?php echo e(Form::label('bathroom', 'En-suite bathroom:')); ?>

      <?php echo e(Form::radio('bathroom', '1')); ?> Yes
      <?php echo e(Form::radio('bathroom', '0', true)); ?> No
    </div>
    <div class="form-group cPost">
      <?php echo e(Form::label('wifi', 'Free Wi-Fi:')); ?>

      <?php echo e(Form::radio('wifi', '1')); ?> Yes
      <?php echo e(Form::radio('wifi', '0', true)); ?> No
    </div>
    <div class="form-group cPost">
      <?php echo e(Form::label('parking', 'Free parking:')); ?>

      <?php echo e(Form::radio('parking', '1')); ?> Yes
      <?php echo e(Form::radio('parking', '0', true)); ?> No
    </div>
    <div class="form-group cPost">
      <?php echo e(Form::label('breakfast', 'Breakfast included:')); ?>

      <?php echo e(Form::radio('breakfast', '1')); ?> Yes
      <?php echo e(Form::radio('breakfast', '0', true)); ?> No
    </div><div class="form-group cPost">
      <?php echo e(Form::label('price', 'Price:')); ?>

      <?php echo e(Form::text('price', old('price'), ['class' => 'form-control', 'placeholder' => 'e.g. 56.99'])); ?>

    </div>
    <div class="form-group">
      <?php echo e(Form::file('room_image')); ?>

    </div>
    <?php echo e(Form::hidden('hotel_id', $hotel_id)); ?>

    <?php echo e(Form::submit('Submit', ['class'=>'btn btn-primary'])); ?>

  <?php echo Form::close(); ?>

</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>