<?php $__env->startSection('content'); ?>
    <div class="card mt-3 mb-3">
        <h5 class="card-header">Listing <?php echo e($room->id); ?></h5>
        <div class="card-body">
            <?php if($room->booked == 1): ?>
                <del>
            <?php endif; ?>

            <div class="row">
              <div class="col-8 col-sm-8">
                <!-- Single beds -->
                <?php if($room->singleBeds > 0): ?> <p><?php echo e($room->singleBeds); ?> single bed(s)</p> <?php endif; ?>

                <!-- Double beds -->
                <?php if($room->doubleBeds > 0): ?> <p><?php echo e($room->doubleBeds); ?> double bed(s)</p> <?php endif; ?>

                <!-- Bathroom/en-suite -->
                <p><?php if($room->bathroom == 0): ?> No bathroom in room. <?php else: ?> En-suite. <?php endif; ?></p>

                <!-- Wi-Fi -->
                <p><?php if($room->wifi == 0): ?> No free Wi-Fi. <?php else: ?> Free Wi-Fi. <?php endif; ?></p>

                <!-- Wi-Fi -->
                <p><?php if($room->parking == 0): ?> No free parking. <?php else: ?> Free parking. <?php endif; ?></p>

                <!-- Wi-Fi -->
                <p><?php if($room->breakfast == 0): ?> Breakfast not included. <?php else: ?> Breakfast included. <?php endif; ?></p>

                <!-- Price -->
                <p>Price: €<?php echo e($room->price); ?></p>

                <?php if((!Auth::guest() && auth()->user()->type == 'admin') || (!Auth::guest() && auth()->user()->type == 'hotel')): ?>
                    <?php echo Form::open(['action' => ['RoomsController@destroy', $room->id], 'method' => 'POST', 'class'=> 'float-right']); ?>

                    <?php echo e(Form::hidden('_method', 'DELETE')); ?>

                    <a href="/rooms/<?php echo e($room->id); ?>/edit" class="btn btn-primary">Edit</a>
                    <?php echo e(Form::submit('Delete', ['class' => 'btn btn-danger'])); ?>

                    <?php echo Form::close(); ?>

                <?php else: ?>
                    <!-- booking link -->
                    <?php if($room->booked == 0): ?> <a class="btn btn-primary" href="/bookings/create/<?php echo e($room->id); ?>">Book</a> <?php endif; ?>
                <?php endif; ?>
              </div>
              <div class="col-4 col-sm-4">
                  <img src="/storage/images/room_images/<?php echo e($room->room_image); ?>">
              </div>
            </div>

            <?php if($room->booked == 1): ?>
                </del> <p class="text-danger">Apologies. This room is already booked.</p>
            <?php endif; ?>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>