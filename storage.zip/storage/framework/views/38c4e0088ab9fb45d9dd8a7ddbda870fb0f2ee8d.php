<?php $__env->startSection('content'); ?>
<div class="container J-margin">
  <h1>Hotels</h1>
  <?php if(count($hotels) > 0): ?>
    <?php $__currentLoopData = $hotels; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $hotel): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
      <div class="card cardMargin">
        <div class="card-body">
          <h2><a href="/hotels/<?php echo e($hotel->id); ?>"><?php echo e($hotel->name); ?></a></h2>
        </div>
      </div>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    <?php echo e($hotels->links()); ?>

  <?php else: ?>
    <p>No hotels found</p>
  <?php endif; ?>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>