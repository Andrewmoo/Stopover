<?php $__env->startSection('content'); ?>
<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8">
            <div class="card">
                <div class="card-header tertiaryColor text-white">Register</div>

                <div class="card-body">
                    <form method="POST" action="<?php echo e(route('register')); ?>">
                        <?php echo csrf_field(); ?>

                        <div class="card-title">
                            <h3 class="text-info">Account Information</h3>
                        </div>
                        <div class="form-group row">
                            <label for="role_id" class="col-md-4 col-form-label text-md-right">Account type:</label>
                            <div class="col-md-6">
                                
                                <a id="role_guest" class="text-white btn btn-primary">Guest</a>
                                <a id="role_hotel" class="text-white btn btn-secondary">Hotel</a>
                                <?php if(empty(old('role_id'))): ?>
                                    <?php echo e(Form::hidden('role_id', '1')); ?>

                                <?php else: ?>
                                    <?php echo e(Form::hidden('role_id', old('role_id'))); ?>

                                <?php endif; ?>

                                <?php if($errors->has('role_id')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('role_id')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                                <label for="username" class="col-md-4 col-form-label text-md-right">Username:</label>
    
                                <div class="col-md-6">
                                    <input id="username" type="text" class="form-control<?php echo e($errors->has('username') ? ' is-invalid' : ''); ?>" name="username" value="<?php echo e(old('username')); ?>" required>
    
                                    <?php if($errors->has('username')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('username')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>

                        <div class="form-group row">
                            <label for="email" class="col-md-4 col-form-label text-md-right">E-mail address:</label>

                            <div class="col-md-6">
                                <input id="email" type="email" class="form-control<?php echo e($errors->has('email') ? ' is-invalid' : ''); ?>" name="email" value="<?php echo e(old('email')); ?>" required>

                                <?php if($errors->has('email')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('email')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password" class="col-md-4 col-form-label text-md-right">Password:</label>

                            <div class="col-md-6">
                                <input id="password" type="password" class="form-control<?php echo e($errors->has('password') ? ' is-invalid' : ''); ?>" name="password" required>

                                <?php if($errors->has('password')): ?>
                                    <span class="invalid-feedback" role="alert">
                                        <strong><?php echo e($errors->first('password')); ?></strong>
                                    </span>
                                <?php endif; ?>
                            </div>
                        </div>

                        <div class="form-group row">
                            <label for="password-confirm" class="col-md-4 col-form-label text-md-right">Confirm password:</label>

                            <div class="col-md-6">
                                <input id="password-confirm" type="password" class="form-control" name="password_confirmation" required>
                            </div>
                        </div>

                        
                        <div id="guestInfo" class="card-title text-dark">
                            <h3 class="text-info">Guest Information</h3>
                            <div class="form-group row">
                                <?php echo e(Form::label('firstName', 'First name:', ['class' => 'col-md-4 col-form-label text-md-right'])); ?>

                                <div class="col-md-6">
                                    <input id="firstName" name="firstName" value="<?php echo e(old('firstName')); ?>" type="text" class="form-control <?php echo e($errors->has('firstName') ? ' is-invalid' : ''); ?>" required>
                                    <?php if($errors->has('firstName')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('firstName')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                </div>
                            </div>
                            <div class="form-group row">
                                <?php echo e(Form::label('lastName', 'Last name:', ['class' => 'col-md-4 col-form-label text-md-right'])); ?>

                                <div class="col-md-6">
                                    <input id="lastName" name="lastName" value="<?php echo e(old('lastName')); ?>" type="text" class="form-control <?php echo e($errors->has('lastName') ? ' is-invalid' : ''); ?>" required>
                                    <?php if($errors->has('lastName')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('lastName')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                            <div class="form-group row">
                                <?php echo e(Form::label('guest_address', 'Address:', ['class' => 'col-md-4 col-form-label text-md-right'])); ?>

                                <div class="col-md-6">
                                    <input id="guest_address" name="guest_address" value="<?php echo e(old('guest_address')); ?>" type="text" class="form-control <?php echo e($errors->has('guest_address') ? ' is-invalid' : ''); ?>" required>
                                    <?php if($errors->has('guest_address')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('guest_address')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                            <div class="form-group row">
                                <?php echo e(Form::label('guest_phone', 'Phone number:', ['class' => 'col-md-4 col-form-label text-md-right'])); ?>

                                <div class="col-md-6">
                                    <input id="guest_phone" name="guest_phone" value="<?php echo e(old('guest_phone')); ?>" type="text" class="form-control <?php echo e($errors->has('guest_phone') ? ' is-invalid' : ''); ?>" required>
                                    <?php if($errors->has('guest_phone')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('guest_phone')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>

                            <div class="form-group row">
                                <?php echo e(Form::label('institution', 'Institution:', ['class' => 'col-md-4 col-form-label text-md-right'])); ?>

                                <div class="col-md-6">
                                    <input id="institution" name="institution" value="<?php echo e(old('institution')); ?>" type="text" class="form-control <?php echo e($errors->has('institution') ? ' is-invalid' : ''); ?>" required>
                                    <?php if($errors->has('institution')): ?>
                                        <span class="invalid-feedback" role="alert">
                                            <strong><?php echo e($errors->first('institution')); ?></strong>
                                        </span>
                                    <?php endif; ?>
                                    
                                </div>
                            </div>
                        </div>

                        <div id="hotelInfo" class="card-title">
                            <h3 class="text-info">Hotel Information</h3>
                            <div class="form-group row">
                                <?php echo e(Form::label('name', 'Name:', ['class' => 'col-md-4 col-form-label text-md-right'])); ?>

                                <div class="col-md-6">
                                <?php echo e(Form::text('name', old('name'), ['class' => 'form-control', 'placeholder' => 'Name of hotel'])); ?>

                                </div>
                            </div>
                            <div class="form-group row">
                                <?php echo e(Form::label('hotel_address', 'Address:', ['class' => 'col-md-4 col-form-label text-md-right'])); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::text('hotel_address', old('address'), ['class' => 'form-control', 'placeholder' => 'Street name, city, province'])); ?>

                                </div>
                            </div>
                            <div class="form-group row">
                                <?php echo e(Form::label('country', 'Country:', ['class' => 'col-md-4 col-form-label text-md-right'])); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::text('country', old('country'), ['class' => 'form-control', 'placeholder' => 'Country'])); ?>

                                </div>
                            </div>
                            <div class="form-group row">
                                <?php echo e(Form::label('hotel_phone', 'Phone:', ['class' => 'col-md-4 col-form-label text-md-right'])); ?>

                                <div class="col-md-6">
                                    <?php echo e(Form::text('hotel_phone', old('hotel_phone'), ['class' => 'form-control', 'placeholder' => 'e.g. +353 867868954'])); ?>

                                </div>
                            </div>
                        </div>

                        <div class="form-group row mb-0">
                            <div class="col-md-6 offset-md-4">
                                <button type="submit" class="btn btn-secondary">
                                    <?php echo e(__('Register')); ?>

                                </button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
</div>
<script>
    // hide hotel specific portion of the form initially
    $('#hotelInfo').hide();
    $( document ).ready(function () {

        // click event for Guest button
        $( '#role_guest' ).click(function () {
            if($('#role_guest').hasClass('btn-secondary')) {

                // swap classes on buttons
                $(this).removeClass('btn-secondary').addClass('btn-primary');
                $('#role_hotel').removeClass('btn-primary').addClass('btn-secondary');

                // change hidden role_id field value
                $("input[name=role_id]").val('1');

                // change visibility of relevant form portions
                $('#guestInfo').show();
                $('#hotelInfo').hide();
            }
        });

        // click event for Hotel button
        $( '#role_hotel' ).click(function () {
            if($('#role_hotel').hasClass('btn-secondary')) {

                // swap classes on buttons
                $(this).removeClass('btn-secondary').addClass('btn-primary');
                $('#role_guest').removeClass('btn-primary').addClass('btn-secondary');

                // change hidden role_id field value
                $("input[name=role_id]").val('3');

                // change visibility of relevant form portions
                $('#guestInfo').hide();
                $('#hotelInfo').show();
            }
        });

        $( 'input' ).click(function () {
            $(this).removeClass('is-invalid');
        });
    })
</script>
<?php $__env->stopSection(); ?>

<?php echo $__env->make('layouts.app', \Illuminate\Support\Arr::except(get_defined_vars(), array('__data', '__path')))->render(); ?>